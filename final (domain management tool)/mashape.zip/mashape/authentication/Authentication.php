<?php
interface Authentication {
	public function handleHeaders();

	public function handleParams();
}
?>